package com.example.exam;

import android.content.Intent;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.exam.databinding.ActivityResultBinding;

public class resultActivity extends AppCompatActivity {

    private ActivityResultBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

         binding = ActivityResultBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

         ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

         Intent intent = getIntent();
        if (intent != null) {
            String num1 = intent.getStringExtra("FIRST_NUMBER");
            String num2 = intent.getStringExtra("SECOND_NUMBER");
            double result = intent.getDoubleExtra("FINAL_RESULT", 0.0);
            String operation = intent.getStringExtra("OPERATION_TYPE");

             String displayText = "Calculation Details:\n\n" +
                    "First Number: " + num1 + "\n" +
                    "Second Number: " + num2 + "\n" +
                    "Operation Performed: " + operation + "\n" +
                    "Final Result: " + result;

             if (binding.tvAllData != null) {
                binding.tvAllData.setText(displayText);
            }
        }
    }
}