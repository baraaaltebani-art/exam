package com.example.exam;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.exam.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    public static ActivityMainBinding mainBinding;


    private double currentResult = 0.0;
    private int lastClickedColor = Color.BLACK;
    private String firstNumberStr = "";
    private String secondNumberStr = "";
    private String lastOperation = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(mainBinding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        if (savedInstanceState != null) {
            currentResult = savedInstanceState.getDouble("RESULT_KEY");
            lastClickedColor = savedInstanceState.getInt("COLOR_KEY");
            firstNumberStr = savedInstanceState.getString("NUM1_KEY");
            secondNumberStr = savedInstanceState.getString("NUM2_KEY");
            lastOperation = savedInstanceState.getString("OP_KEY");

            mainBinding.textViewAllData.setText(String.valueOf(currentResult));
            mainBinding.textViewAllData.setTextColor(lastClickedColor);
        }

        mainBinding.buttonMul.setOnClickListener(v -> calculate("+", Color.parseColor("#4CAF50")));
        mainBinding.buttonSUB.setOnClickListener(v -> calculate("-", Color.parseColor("#F44336")));
        mainBinding.buttonDIV.setOnClickListener(v -> calculate("/", Color.parseColor("#FF9800")));
        mainBinding.buttonMul.setOnClickListener(v -> calculate("*", Color.parseColor("#2196F3")));

        // 3. الانتقال للشاشة الثانية عند الضغط على نص النتيجة (textViewAllData)
        mainBinding.textViewAllData.setOnClickListener(v -> {
            if (lastOperation.isEmpty()) {
                Toast.makeText(this, "Please perform a calculation first", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(MainActivity.this, resultActivity.class);
            intent.putExtra("FIRST_NUMBER", firstNumberStr);
            intent.putExtra("SECOND_NUMBER", secondNumberStr);
            intent.putExtra("FINAL_RESULT", currentResult);
            intent.putExtra("OPERATION_TYPE", lastOperation);
            startActivity(intent);
        });
    }


    private void calculate(String operation, int buttonColor) {
        if (mainBinding.buttonSUB == null || mainBinding.editTextSecondNumber == null) {
            Toast.makeText(this, " XML", Toast.LENGTH_LONG).show();
            return;
        }

        firstNumberStr = mainBinding.buttonSUB.getText().toString().trim();
        secondNumberStr = mainBinding.editTextSecondNumber.getText().toString().trim();

        if (firstNumberStr.isEmpty() || secondNumberStr.isEmpty()) {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        double num1 = Double.parseDouble(firstNumberStr);
        double num2 = Double.parseDouble(secondNumberStr);
        lastOperation = operation;
        lastClickedColor = buttonColor;

        switch (operation) {
            case "+": currentResult = num1 + num2; break;
            case "-": currentResult = num1 - num2; break;
            case "*": currentResult = num1 * num2; break;
            case "/":
                if (num2 == 0) {
                    Toast.makeText(this, "Cannot divide by zero!", Toast.LENGTH_SHORT).show();
                    return;
                }
                currentResult = num1 / num2;
                break;
        }


        mainBinding.textViewAllData.setText(String.valueOf(currentResult));
        mainBinding.textViewAllData.setTextColor(lastClickedColor);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putDouble("RESULT_KEY", currentResult);
        outState.putInt("COLOR_KEY", lastClickedColor);
        outState.putString("NUM1_KEY", firstNumberStr);
        outState.putString("NUM2_KEY", secondNumberStr);
        outState.putString("OP_KEY", lastOperation);
    }
}